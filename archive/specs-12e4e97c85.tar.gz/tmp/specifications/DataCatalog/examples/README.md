## DataCatalog coding examples. 
Folder that stores JSON-LD, RDFa or microdata examples.
