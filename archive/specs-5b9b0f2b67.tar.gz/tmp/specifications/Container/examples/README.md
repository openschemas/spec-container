## Container coding examples. 
Folder that stores JSON-LD, RDFa or microdata examples.
>Examples will be added in a future map2model release.
